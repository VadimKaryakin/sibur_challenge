
import pickle
import pathlib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from sklearn.linear_model import RidgeCV
from sklearn.svm import LinearSVR
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import StackingRegressor

MODEL_FILE = pathlib.Path(__file__).parent.joinpath("baseline_model.cbm")
AGG_COLS = ["material_code", "company_code", "country", "region", "manager_code"]
FTS_COLS = ["material_code", "company_code", "country", "region", "manager_code", "month",
            "vol_tm6", "vol_tm5", "vol_tm4", "vol_tm3", "vol_tm2", "vol_tm1",
            "last_year_avg", "last_year_min", "last_year_max"]

def get_features(df: pd.DataFrame, month: pd.Timestamp) -> pd.DataFrame:
    """Вычисление признаков для `month`."""

    start_period = month - pd.offsets.MonthBegin(6)
    end_period = month - pd.offsets.MonthBegin(1)

    df = df.loc[:, :end_period]

    features = pd.DataFrame([], index=df.index)
    features["month"] = month.month
    features[[f"vol_tm{i}" for i in range(6, 0, -1)]] = df.loc[:, start_period:end_period].copy()

    rolling = df.rolling(12, axis=1, min_periods=1)
    features = features.join(rolling.mean().iloc[:, -1].rename("last_year_avg"))
    features = features.join(rolling.min().iloc[:, -1].rename("last_year_min"))
    features = features.join(rolling.max().iloc[:, -1].rename("last_year_max"))
    features["month"] = month.month
    return features.reset_index()


def predict(df: pd.DataFrame, month: pd.Timestamp) -> pd.DataFrame:
    """
    Вычисление предсказаний.

    Параметры:
        df:
          датафрейм, содержащий все сделки с начала тренировочного периода до `month`; типы
          колонок совпадают с типами в ноутбуке `[SC2021] Baseline`,
        month:
          месяц, для которого вычисляются предсказания.

    Результат:
        Датафрейм предсказаний для каждой группы, содержащий колонки:
            - `material_code`, `company_code`, `country`, `region`, `manager_code`,
            - `prediction`.
        Предсказанные значения находятся в колонке `prediction`.
    """

    group_ts = df.groupby(AGG_COLS + ["month"])["volume"].sum().unstack(fill_value=0)
    features = get_features(group_ts, month)
    save_cols = features[['country', 'region']].copy()
    features['country'] = preprocessing.LabelEncoder().fit_transform(features['country'])
    features['region'] = preprocessing.LabelEncoder().fit_transform(features['region'])


    #model = CatBoostRegressor()
    #model.load_model(MODEL_FILE)
    model = pickle.load(open(pathlib.Path(__file__).parent.joinpath("reg_model.pkl"), "rb"))
    predictions = model.predict(features[FTS_COLS])

    preds_df = features[AGG_COLS].copy()
    preds_df["prediction"] = predictions
    preds_df[['country', 'region']] = save_cols
    return preds_df
    