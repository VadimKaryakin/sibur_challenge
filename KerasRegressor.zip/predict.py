import numpy as np
import pickle
import pathlib
import pandas as pd
import joblib
#from sklearn.model_selection import train_test_split
from sklearn import preprocessing
import tensorflow as tf
#from sklearn.linear_model import RidgeCV
#from sklearn.svm import LinearSVR
#from sklearn.ensemble import RandomForestRegressor
#from sklearn.linear_model import LinearRegression
#from sklearn.pipeline import make_pipeline
#from sklearn.ensemble import StackingRegressor

from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.wrappers.scikit_learn import KerasRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold, cross_val_score
from sklearn.model_selection import train_test_split

MODEL_FILE = pathlib.Path(__file__).parent.joinpath("baseline_model.cbm")
AGG_COLS = ["material_code", "company_code", "country", "region", "manager_code"]
FTS_COLS = ["material_code", "company_code", "country", "region", "manager_code", "month",
            "vol_tm6", "vol_tm5", "vol_tm4", "vol_tm3", "vol_tm2", "vol_tm1",
            "last_year_avg", "last_year_min", "last_year_max"]
            
from keras import backend as K
def root_mean_squared_log_error(y_true, y_pred):
    return K.sqrt(K.mean(K.square(y_pred - y_true))) 

def wider_model():
  model = Sequential()
  model.add(Dense(50, input_dim=15, kernel_initializer='normal', activation='relu'))
  model.add(Dense(70, kernel_initializer='normal', activation='relu'))
  model.add(Dropout(.2))
  model.add(Dense(70, kernel_initializer='normal', activation='relu'))
  model.add(Dropout(.2))
  model.add(Dense(1, kernel_initializer='normal'))
  model.compile(loss=tf.keras.losses.mean_squared_logarithmic_error, optimizer=tf.keras.optimizers.Adadelta(learning_rate=0.004)) #root_mean_squared_log_error
  return model

def get_features(df: pd.DataFrame, month: pd.Timestamp) -> pd.DataFrame:
    """Вычисление признаков для `month`."""

    start_period = month - pd.offsets.MonthBegin(6)
    end_period = month - pd.offsets.MonthBegin(1)

    df = df.loc[:, :end_period]

    features = pd.DataFrame([], index=df.index)
    features["month"] = month.month
    features[[f"vol_tm{i}" for i in range(6, 0, -1)]] = df.loc[:, start_period:end_period].copy()

    rolling = df.rolling(12, axis=1, min_periods=1)
    features = features.join(rolling.mean().iloc[:, -1].rename("last_year_avg"))
    features = features.join(rolling.min().iloc[:, -1].rename("last_year_min"))
    features = features.join(rolling.max().iloc[:, -1].rename("last_year_max"))
    features["month"] = month.month
    return features.reset_index()


def predict(df: pd.DataFrame, month: pd.Timestamp) -> pd.DataFrame:
    """
    Вычисление предсказаний.

    Параметры:
        df:
          датафрейм, содержащий все сделки с начала тренировочного периода до `month`; типы
          колонок совпадают с типами в ноутбуке `[SC2021] Baseline`,
        month:
          месяц, для которого вычисляются предсказания.

    Результат:
        Датафрейм предсказаний для каждой группы, содержащий колонки:
            - `material_code`, `company_code`, `country`, `region`, `manager_code`,
            - `prediction`.
        Предсказанные значения находятся в колонке `prediction`.
    """
    import os
    import sys
    sys.path.append(os.getcwd()+"launcher/")

    from predict import wider_model

    group_ts = df.groupby(AGG_COLS + ["month"])["volume"].sum().unstack(fill_value=0)
    features = get_features(group_ts, month)
    save_cols = features[['country', 'region']].copy()
    features['country'] = preprocessing.LabelEncoder().fit_transform(features['country'])
    features['region'] = preprocessing.LabelEncoder().fit_transform(features['region'])

    #model = CatBoostRegressor()
    #model.load_model(MODEL_FILE)
    model = pickle.load(open(pathlib.Path(__file__).parent.joinpath("pipeline.pkl"), "rb"))
    #model = joblib.load(pathlib.Path(__file__).parent.joinpath("pipeline.pkl"))
    predictions = np.abs(model.predict(features[FTS_COLS]))

    preds_df = features[AGG_COLS].copy()
    preds_df["prediction"] = predictions
    preds_df[['country', 'region']] = save_cols
    return preds_df
    