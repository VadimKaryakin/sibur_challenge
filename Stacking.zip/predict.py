
import pathlib
import pandas as pd
import pickle
from catboost import CatBoostRegressor
from sklearn import preprocessing
from xgboost import XGBRegressor, Booster
from xgboost import plot_importance
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression

AGG_COLS = ["material_code", "company_code", "country", "region", "manager_code"]

def get_features(df: pd.DataFrame, month: pd.Timestamp) -> pd.DataFrame:
    """Вычисление признаков для `month`."""

    start_period = month - pd.offsets.MonthBegin(6)
    end_period = month - pd.offsets.MonthBegin(1)

    df = df.loc[:, :end_period]

    features = pd.DataFrame([], index=df.index)
    features["month"] = month.month
    features[[f"vol_tm{i}" for i in range(6, 0, -1)]] = df.loc[:, start_period:end_period].copy()

    rolling = df.rolling(12, axis=1, min_periods=1)
    features = features.join(rolling.mean().iloc[:, -1].rename("last_year_avg"))
    features = features.join(rolling.min().iloc[:, -1].rename("last_year_min"))
    features = features.join(rolling.max().iloc[:, -1].rename("last_year_max"))
    features["month"] = month.month
    return features.reset_index()


def predict(df: pd.DataFrame, month: pd.Timestamp) -> pd.DataFrame:
    """
    Вычисление предсказаний.

    Параметры:
        df:
          датафрейм, содержащий все сделки с начала тренировочного периода до `month`; типы
          колонок совпадают с типами в ноутбуке `[SC2021] Baseline`,
        month:
          месяц, для которого вычисляются предсказания.

    Результат:
        Датафрейм предсказаний для каждой группы, содержащий колонки:
            - `material_code`, `company_code`, `country`, `region`, `manager_code`,
            - `prediction`.
        Предсказанные значения находятся в колонке `prediction`.
    """

    group_ts = df.groupby(AGG_COLS + ["month"])["volume"].sum().unstack(fill_value=0)
    features = get_features(group_ts, month)

    save_cols = features[['country', 'region']].copy()
    features['country'] = preprocessing.LabelEncoder().fit_transform(features['country'])
    features['region'] = preprocessing.LabelEncoder().fit_transform(features['region'])

    #####
    cat_model_loaded = CatBoostRegressor()
    cat_model_loaded.load_model(pathlib.Path(__file__).parent.joinpath("cat_model.cbm"))
    
    meta_model_loaded = CatBoostRegressor()
    meta_model_loaded.load_model(pathlib.Path(__file__).parent.joinpath("meta_model.cbm"))

    xgb_model_loaded = XGBRegressor(max_depth=8, 
                         n_estimators=500, 
                         min_child_weight=1000,  
                         colsample_bytree=0.7, 
                         subsample=0.7, 
                         eta=0.3, 
                         seed=0) #Booster() #pickle.load(open(pathlib.Path(__file__).parent.joinpath("xgb_model.pkl"), "rb"))
    xgb_model_loaded.load_model(pathlib.Path(__file__).parent.joinpath("xgb_model.bin"))
    rf_model_loaded = pickle.load(open(pathlib.Path(__file__).parent.joinpath("rf_model.pkl"), "rb"))
    extra_trees_loaded = pickle.load(open(pathlib.Path(__file__).parent.joinpath("extra_trees_model.pkl"), "rb"))
    
    #####
    first_level = pd.DataFrame(cat_model_loaded.predict(features[cat_model_loaded.feature_names_]), columns=['catboost'])
    first_level['xgbm'] = xgb_model_loaded.predict(features[cat_model_loaded.feature_names_])
    first_level['random_forest'] = rf_model_loaded.predict(features[cat_model_loaded.feature_names_])
    first_level['extra_trees'] = extra_trees_loaded.predict(features[cat_model_loaded.feature_names_])
    first_level['catboost'] = first_level['catboost'].abs()
    first_level['xgbm'] = first_level['xgbm'].abs()
    first_level['random_forest']  = first_level['random_forest'].abs() 
    first_level['extra_trees'] = first_level['extra_trees'].abs()

    predictions = meta_model_loaded.predict(first_level)
    preds_df = features[AGG_COLS].copy()
    preds_df["prediction"] = predictions
    preds_df[['country', 'region']] = save_cols
    return preds_df
    